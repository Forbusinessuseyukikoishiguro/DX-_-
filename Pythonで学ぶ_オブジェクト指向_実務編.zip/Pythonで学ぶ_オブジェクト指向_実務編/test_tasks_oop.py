"""tasks_oop.py のテスト。実行: python -m unittest test_tasks_oop -v"""
import unittest
from tasks_oop import Task, DevTask, MeetingTask, ReviewTask, Member


class TestTasks(unittest.TestCase):
    def test_dev_task_billable_equals_hours(self):
        self.assertEqual(DevTask("a", 2.0).billable_hours(), 2.0)

    def test_meeting_counts_half(self):
        self.assertEqual(MeetingTask("会議", 3.0).billable_hours(), 1.5)

    def test_review_is_a_dev_task(self):
        # 継承：ReviewTask は DevTask の一種
        self.assertTrue(isinstance(ReviewTask("r", 1.0), DevTask))
        self.assertEqual(ReviewTask("r", 1.0).billable_hours(), 1.0)

    def test_abstract_base_cannot_be_created(self):
        with self.assertRaises(TypeError):
            Task("x", 1.0)

    def test_negative_hours_rejected(self):
        with self.assertRaises(ValueError):
            DevTask("x", -0.5)

    def test_encapsulation_read_only_property(self):
        t = DevTask("x", 1.0)
        with self.assertRaises(AttributeError):
            t.hours = 5.0   # property に代入はできない

    def test_member_totals_use_polymorphism(self):
        m = Member("佐藤")
        m.add(DevTask("a", 4.0))
        m.add(MeetingTask("b", 2.0))
        self.assertEqual(m.total_hours(), 6.0)
        self.assertEqual(m.total_billable(), 5.0)   # 4 + 2*0.5

    def test_member_starts_empty_and_separate(self):
        # dataclass の default_factory: 担当者ごとに別のリストを持つ
        a, b = Member("A"), Member("B")
        a.add(DevTask("x", 1.0))
        self.assertEqual(len(b.tasks), 0)


if __name__ == "__main__":
    unittest.main()
