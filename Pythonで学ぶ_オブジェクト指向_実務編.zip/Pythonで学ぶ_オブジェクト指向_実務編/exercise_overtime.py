"""課題：残業（OvertimeTask）を追加する。請求対象は、記録した時間の1.25倍とする（仮の規則）。
ヒント：Task を継承し、billable_hours() だけを書き換える。
"""
from tasks_oop import Task


# ここに OvertimeTask を書いてください
class OvertimeTask(Task):
    def billable_hours(self) -> float:
        return self.hours * 1.25
