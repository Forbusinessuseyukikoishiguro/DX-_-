"""課題の答え合わせ。実行: python -m unittest test_exercise -v"""
import unittest
from exercise_overtime import OvertimeTask

class TestOvertime(unittest.TestCase):
    def test_overtime_billable(self):
        self.assertEqual(OvertimeTask("夜間対応", 4.0).billable_hours(), 5.0)
    def test_is_task(self):
        from tasks_oop import Task
        self.assertTrue(issubclass(OvertimeTask, Task))

if __name__ == "__main__":
    unittest.main()
