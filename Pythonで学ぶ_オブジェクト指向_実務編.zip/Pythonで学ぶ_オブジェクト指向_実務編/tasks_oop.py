"""オブジェクト指向の実務例：業務タスクの工数と請求対象時間。
講座で扱う要素: クラス・インスタンス・カプセル化（property）・継承・抽象基底クラス（ABC）・
ポリモーフィズム・dataclass・継承より合成（組み合わせ）。
Python 3.10 以上で動作確認（dataclassの match_args などの仕様は公式ドキュメントで確認）。
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field


class Task(ABC):
    """工数の記録の共通の型。直接は作れない（抽象基底クラス）。"""

    def __init__(self, title: str, hours: float):
        if hours < 0:
            raise ValueError("工数は0以上にしてください")
        self._title = title       # 先頭の _ は「外から直接触らないでね」という約束
        self._hours = hours

    @property
    def title(self) -> str:
        return self._title

    @property
    def hours(self) -> float:
        return self._hours

    @abstractmethod
    def billable_hours(self) -> float:
        """請求の対象になる時間。種類ごとに、子クラスが決める。"""

    def __repr__(self) -> str:
        return f"{type(self).__name__}({self._title!r}, {self._hours})"


class DevTask(Task):
    """開発の作業：記録した時間をそのまま請求の対象にする。"""

    def billable_hours(self) -> float:
        return self.hours


class MeetingTask(Task):
    """会議：ここでは半分を請求の対象とする（仮の規則。実際の規則は社内で決める）。"""

    def billable_hours(self) -> float:
        return self.hours * 0.5


class ReviewTask(DevTask):
    """レビュー：開発と同じ扱い。継承して、名前だけ変える例。"""

    def __repr__(self) -> str:
        return f"レビュー({self.title!r}, {self.hours})"


@dataclass
class Member:
    """担当者。タスクの一覧を持つ（合成：タスクを部品として組み込む）。"""
    name: str
    tasks: list[Task] = field(default_factory=list)

    def add(self, task: Task) -> None:
        self.tasks.append(task)

    def total_hours(self) -> float:
        return sum(t.hours for t in self.tasks)

    def total_billable(self) -> float:
        # ポリモーフィズム：中身の型が何であっても、billable_hours() を呼ぶだけでよい
        return sum(t.billable_hours() for t in self.tasks)


if __name__ == "__main__":
    sato = Member("佐藤")
    sato.add(DevTask("在庫APIの実装", 3.5))
    sato.add(MeetingTask("顧客打ち合わせ", 1.5))
    sato.add(ReviewTask("決済画面のレビュー", 1.0))

    print(sato)
    print("合計:", sato.total_hours(), "請求対象:", sato.total_billable())
    try:
        Task("テスト", 1.0)
    except TypeError as e:
        print("抽象クラスは直接作れない:", e)
    try:
        DevTask("負の工数", -1)
    except ValueError as e:
        print("エラー:", e)
