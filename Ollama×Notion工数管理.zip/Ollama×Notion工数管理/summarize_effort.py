#!/usr/bin/env python3
"""Notionの工数DBをCSVで書き出したファイルを集計し、週報の下書きをローカルのOllamaで作る。
使い方:
  python summarize_effort.py sample_timesheet.csv            # 集計だけ表示（Ollama不要）
  python summarize_effort.py sample_timesheet.csv --ask      # Ollamaに週報の下書きを作らせる
  python summarize_effort.py sample_timesheet.csv --ask --model llama3.2
必要な列: 日付, 担当, 案件, カテゴリ, 作業内容, 工数(h)
  ※ 列名が違うときは COLUMNS を書き換える。日付の書き方はNotionの設定で変わることがある。
"""
import sys, csv, argparse
from datetime import datetime, date
from collections import defaultdict

COLUMNS = {"date": "日付", "person": "担当", "project": "案件", "category": "カテゴリ", "task": "作業内容", "hours": "工数(h)"}
DAY_LIMIT_H = 10.0  # この時間を超えた日は確認を促す（目安。社内の労務ルールを優先すること）

def parse_date(s):
    s = s.strip()
    for fmt in ("%Y-%m-%d", "%Y/%m/%d", "%B %d, %Y", "%b %d, %Y"):
        try:
            return datetime.strptime(s, fmt).date()
        except ValueError:
            pass
    raise ValueError(s)

def load(path):
    rows, problems = [], []
    with open(path, encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        missing = [v for v in COLUMNS.values() if v not in (reader.fieldnames or [])]
        if missing:
            sys.exit(f"列が見つかりません: {missing}\n先頭行の列名: {reader.fieldnames}")
        for n, r in enumerate(reader, start=2):
            try:
                d = parse_date(r[COLUMNS["date"]])
            except ValueError:
                problems.append(f"{n}行目: 日付を読めない（{r[COLUMNS['date']]}）"); continue
            h_raw = r[COLUMNS["hours"]].strip()
            try:
                h = float(h_raw)
            except ValueError:
                problems.append(f"{n}行目: 工数が空または数値でない（{d} {r[COLUMNS['person']]}）"); continue
            rows.append({"date": d, "person": r[COLUMNS["person"]], "project": r[COLUMNS["project"]],
                         "category": r[COLUMNS["category"]], "task": r[COLUMNS["task"]], "hours": h})
    return rows, problems

def summarize(rows, problems):
    total = sum(r["hours"] for r in rows)
    def agg(key):
        d = defaultdict(float)
        for r in rows: d[r[key]] += r["hours"]
        return sorted(d.items(), key=lambda kv: -kv[1])
    weeks = defaultdict(float)
    for r in rows: weeks[f"{r['date'].isocalendar()[0]}年 第{r['date'].isocalendar()[1]}週"] += r["hours"]
    day = defaultdict(float)
    for r in rows: day[(r["date"], r["person"])] += r["hours"]
    over = [(d, p, h) for (d, p), h in sorted(day.items()) if h > DAY_LIMIT_H]
    lines = [f"合計: {total:.1f}時間（{len(rows)}件）"]
    lines.append("【案件別】" + "、".join(f"{k} {v:.1f}h" for k, v in agg("project")))
    lines.append("【担当別】" + "、".join(f"{k} {v:.1f}h" for k, v in agg("person")))
    lines.append("【カテゴリ別】" + "、".join(f"{k} {v:.1f}h" for k, v in agg("category")))
    lines.append("【週別】" + "、".join(f"{k} {v:.1f}h" for k, v in sorted(weeks.items())))
    lines.append("【確認が必要な日】" + ("、".join(f"{d} {p} {h:.1f}h" for d, p, h in over) if over else "なし（1日あたり上限目安を超えた日はありません）"))
    lines.append("【入力の問題】" + ("、".join(problems) if problems else "なし"))
    return "\n".join(lines)

def ask_ollama(summary, model):
    try:
        import ollama
    except ImportError:
        sys.exit("ollamaライブラリがありません。仮想環境で pip install ollama を実行してください。")
    prompt = ("次は、チームの工数の集計結果です。この数字だけを使って、週報の下書きを日本語で作ってください。"
              "数字を新しく作ったり、書かれていない作業を推測したりしないでください。"
              "最後に『確認してほしい点』を短く書いてください。\n\n" + summary)
    try:
        res = ollama.chat(model=model, messages=[{"role": "user", "content": prompt}])
    except Exception as e:
        sys.exit(f"Ollamaに接続できません（起動しているか、モデル'{model}'を pull 済みか確認）: {e}")
    return res["message"]["content"]

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("csv")
    ap.add_argument("--ask", action="store_true", help="Ollamaで週報の下書きを作る")
    ap.add_argument("--model", default="llama3.2")
    a = ap.parse_args()
    rows, problems = load(a.csv)
    summary = summarize(rows, problems)
    print(summary)
    if a.ask:
        print("\n----- Ollamaの下書き（必ず自分で確認してください） -----")
        print(ask_ollama(summary, a.model))
