// 台本データ（notes.js）から Markdown 講義台本を生成する。PPTの発表者ノートと同じ元データなので内容が必ず一致する。
// 使い方: node gen_script_md.js <notes.js> <config.json> <出力.md>
// config.json の例:
// {
//   "courseTitle": "◯◯入門 講義台本（講師用）",
//   "deckName": "◯◯入門（39枚）",
//   "selfStudyMinutes": 90,
//   "parts": [["はじめに",1,7],["PART A ...",8,14]],      // [パート名, 開始スライド, 終了スライド]
//   "prep": ["全ミッションを通しで実行しておく", "..."],   // 講師の事前準備
//   "rules": ["問いは答えを言う前に待つ", "..."],           // 進行の基本ルール
//   "troubleTable": [["症状","原因","直し方"], ...],       // 付録A（任意）
//   "quizAnswers": [["Q1","B","解説"], ...],               // 付録B（任意）
//   "officialLinks": [["名前","URL"], ...],                // 付録C（任意）
//   "preReleaseChecks": ["全コマンドを自分の環境で通しで実行した", "..."]  // 付録D
// }
const fs = require("fs");
const path = require("path");
const [, , notesPath, cfgPath, outPath] = process.argv;
if (!notesPath || !cfgPath || !outPath) { console.error("usage: node gen_script_md.js <notes.js> <config.json> <out.md>"); process.exit(1); }
const N = require(path.resolve(notesPath));
const cfg = JSON.parse(fs.readFileSync(cfgPath, "utf8"));
const parts = cfg.parts || [["全体", 1, N.length]];
const sum = (a, b, k) => N.slice(a - 1, b).reduce((s, n) => s + n.m[k], 0);
const r = (x) => Math.round(x);
const tt = sum(1, N.length, 0), tp = sum(1, N.length, 1);
const o = [];
o.push(`# ${cfg.courseTitle || "講義台本（講師用）"}`, "", `対象PPT：${cfg.deckName || ""}`, "", "> 各スライドの発表者ノートにも、同じ内容（セリフ・進行・メモ）が入っています。", "");
o.push("## 1. この台本の使い方", "", "| 記号 | 意味 |", "|---|---|", "| 「　」 | 講師が話すセリフ（動画収録ではそのままナレーション原稿になります） |", "| ［　］ | 進行指示（操作・待ち時間・確認） |", "| メモ | 講師だけが知っておく補足・つまずき対応 |", "");
o.push("## 2. 時間配分", "");
o.push(`- 講義モード（全員で実習しながら）：話す約${r(tt)}分 ＋ 実習約${r(tp)}分 ＝ **約${r(tt + tp)}分**（休憩は別）`);
o.push(`- 動画収録モード（実習は視聴者に任せ、動画を止めてもらう）：話す約${r(tt)}分`);
o.push(`- 自習モード：PPTだけで約${cfg.selfStudyMinutes || 90}分（受講者のペースで前後。実測ではなく目安）`, "");
o.push("| パート | スライド | 話す | 実習 | 合計 |", "|---|---|---|---|---|");
parts.forEach(([n, a, b]) => o.push(`| ${n} | ${a}〜${b} | ${r(sum(a, b, 0))}分 | ${r(sum(a, b, 1))}分 | ${r(sum(a, b, 0) + sum(a, b, 1))}分 |`));
o.push("", "※ 時間は目安です。受講者の環境（特にインストール）で大きく変わります。", "");
if (cfg.prep) { o.push("## 3. 講師の事前準備", ""); cfg.prep.forEach((t, i) => o.push(`${i + 1}. ${t}`)); o.push(""); }
if (cfg.rules) { o.push("## 4. 進行の基本ルール", ""); cfg.rules.forEach((t) => o.push(`- ${t}`)); o.push(""); }
o.push("---", "");
N.forEach((n, i) => {
  const no = i + 1;
  const p = parts.find(([_, a]) => no === a);
  if (p) o.push(`## ${p[0]}`, "");
  o.push(`### スライド${no}　${n.t}`, "", `**時間**：話す${n.m[0]}分／実習${n.m[1]}分`, "");
  n.say.forEach((l) => o.push(`「${l}」`, ""));
  n.act.forEach((l) => o.push(l, ""));
  n.memo.forEach((l) => o.push(`> メモ：${l}`, ""));
});
o.push("---", "");
if (cfg.troubleTable) {
  o.push("## 付録A　つまずき対応 早見表", "", "| 症状 | 原因 | 直し方 |", "|---|---|---|");
  cfg.troubleTable.forEach(([a, b, c]) => o.push(`| ${a} | ${b} | ${c} |`)); o.push("");
}
if (cfg.quizAnswers) {
  o.push("## 付録B　確認テスト 解答", "", "| 問 | 答え | 解説 |", "|---|---|---|");
  cfg.quizAnswers.forEach(([a, b, c]) => o.push(`| ${a} | ${b} | ${c} |`)); o.push("");
}
if (cfg.officialLinks) { o.push("## 付録C　公式ドキュメント（最新はここが正です）", ""); cfg.officialLinks.forEach(([a, b]) => o.push(`- ${a}：${b}`)); o.push(""); }
o.push("## 付録D　公開前チェック（講師用）", "");
(cfg.preReleaseChecks || ["全コマンド・操作を自分の環境で通しで実行した", "要件・コマンド・料金を公式の最新ページで確認した", "スクショに秘密情報・個人情報が写っていない"]).forEach((t) => o.push(`- [ ] ${t}`));
o.push("");
fs.writeFileSync(outPath, o.join("\n"));
console.log(`wrote ${outPath}: ${N.length}枚 話す${r(tt)}分 実習${r(tp)}分`);
