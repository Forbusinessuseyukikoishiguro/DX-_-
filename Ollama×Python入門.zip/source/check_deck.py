#!/usr/bin/env python3
"""PPTの各スライドと発表者ノートの対応を一覧表示し、ノート抜け・題名ずれを検出する。
使い方: python3 check_deck.py deck.pptx
終了コード: 問題なし=0 / ノート抜けあり=1
"""
import sys
from pptx import Presentation


def first_text(slide):
    for sh in slide.shapes:
        if sh.has_text_frame and sh.text_frame.text.strip():
            return sh.text_frame.text.strip().split("\n")[0]
    return ""


def main(path):
    prs = Presentation(path)
    missing = 0
    mismatch = 0
    for i, s in enumerate(prs.slides, 1):
        title = first_text(s)
        note = s.notes_slide.notes_text_frame.text.strip() if s.has_notes_slide else ""
        head = note.split("\n")[0] if note else ""
        if not note:
            missing += 1
            flag = "NO-NOTE"
        else:
            # ノート1行目「【講師用ノート】題名（話す..」の題名が、スライド題名と無関係なら警告
            key = head.replace("【講師用ノート】", "").split("（")[0]
            flag = "ok" if (key == "表紙" or key[:6] in title or title[:6] in key or title.startswith("STEP") or key.startswith("PART")) else "CHECK"
            if flag == "CHECK":
                mismatch += 1
        print(f"{i:>3} [{flag:7}] {title[:30]:30} | {head[:44]}")
    print(f"\nslides={len(prs.slides)} missing_notes={missing} title_check={mismatch}")
    return 1 if missing else 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print(__doc__)
        sys.exit(2)
    sys.exit(main(sys.argv[1]))
