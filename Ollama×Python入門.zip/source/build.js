// Ollama×Python講座 PPT（受講生用・発表者ノート付き）。notes.js と40枚で1対1。
const L = require("./course_lib.js");
const NOTES = require("./notes.js");

(async () => {
  const out = process.argv[2] || "ollama_python_course.pptx";
  const k = await L.create({ title: "Ollama×Python入門", author: "うさうさ研修工房", footer: "Ollama×Python入門 ｜ うさうさ研修工房", theme: {} });
  const { C } = k;
  const code = (lines) => lines;

  k.section("はじめに");
  await k.titleSlide("Ollamaで始める\nローカルAI × Python", "Windows・VS Codeで学ぶ、お金をかけないハンズオン（DXエンジニア向け）", "うさうさ研修工房");

  let s = k.content("この講座の進め方");
  const how = [["FaQuestionCircle", "① 問いに答える", "まず自分で予想します。"], ["FaTerminal", "② ミッションをやる", "手を動かして確かめます。"], ["FaCamera", "③ 画面を貼る", "自分の結果をスクショで残します。"]];
  for (let i = 0; i < 3; i++) await k.card(s, { x: 0.6 + i * 4.1, y: 1.6, w: 3.9, h: 3.3, ic: how[i][0], title: how[i][1], text: how[i][2], bsize: 18 });
  k.bar(s, 0.6, 5.3, 12.1, 1.4, "困ったら15分ルール", "15分進まなければ、STEP7（つまずき対応）へ進みます。");

  s = k.content("この講座でできるようになること");
  const goals = ["Ollamaを入れて、ローカルのモデルと話せる", "PythonからOllamaのモデルを呼び、返事を表示できる", "業務で安全に使う判断（入力情報・確認・コスト）ができる"];
  goals.forEach((g, i) => {
    s.addShape(k.pres.shapes.OVAL, { x: 0.8, y: 1.9 + i * 1.4, w: 0.8, h: 0.8, fill: { color: C.accent1 } });
    k.txt(s, String(i + 1), { x: 0.8, y: 1.9 + i * 1.4, w: 0.8, h: 0.8, fontSize: 24, bold: true, color: C.background1, align: "center", valign: "middle", fontFace: k.THEME.headFontFace });
    k.txt(s, g, { x: 1.9, y: 1.9 + i * 1.4, w: 10.5, h: 0.8, fontSize: 22, valign: "middle" });
  });

  s = k.content("お金の原則");
  await k.card(s, { x: 0.6, y: 1.6, w: 5.9, h: 3.8, ic: "FaCoins", title: "利用料がかからない範囲", text: "Ollama本体はMITライセンスのオープンソース。自分のPCでモデルを動かす範囲では、本体の利用料はかかりません。", bsize: 17 });
  await k.card(s, { x: 6.8, y: 1.6, w: 5.9, h: 3.8, ic: "FaLightbulb", title: "かかる可能性がある範囲", text: "PCの性能・ディスク容量・電気代が必要です。クラウド版は有料の可能性があるので、料金は公式の最新ページで確認してください。", bsize: 17, fill: C.accent1, tcolor: C.accent3, bcolor: C.background1, ibg: C.accent3 });
  k.bar(s, 0.6, 5.8, 12.1, 0.9, "鉄則", "金額は書かず、上限は自分で決める。");

  s = k.content("学習マップ：8段階の波");
  const steps = [["STEP1", "全体像", 1], ["STEP2", "導入", 2], ["STEP3", "お金", 2], ["STEP4", "初回の会話", 2], ["STEP5", "Python", 4], ["STEP6", "会話の継続", 3], ["STEP7", "つまずき", 4], ["STEP8", "安全と演習", 3]];
  steps.forEach(([a, b, d], i) => {
    const x = 0.6 + i * 1.52, h = d * 0.85, base = 5.4;
    s.addShape(k.pres.shapes.RECTANGLE, { x, y: base - h, w: 1.35, h, fill: { color: i % 2 ? C.accent2 : C.accent1 } });
    k.txt(s, a, { x, y: base + 0.1, w: 1.35, h: 0.3, fontSize: 13, bold: true, color: C.accent1, align: "center" });
    k.txt(s, b, { x, y: base + 0.4, w: 1.35, h: 0.3, fontSize: 13, color: C.text1, align: "center" });
  });
  k.txt(s, "棒の高さ＝むずかしさの目安。STEP5とSTEP7が坂、STEP3・STEP4・STEP6が楽しい山です。", { x: 0.6, y: 6.25, w: 12.1, h: 0.5, fontSize: 15, color: C.text1 });

  s = k.content("事前準備");
  await k.card(s, { x: 0.6, y: 1.6, w: 3.9, h: 3.6, ic: "FaDesktop", title: "Windows", text: "Windows 10（22H2以上）または Windows 11。", bsize: 17 });
  await k.card(s, { x: 4.7, y: 1.6, w: 3.9, h: 3.6, ic: "FaDatabase", title: "空き容量", text: "モデルは数GB以上になることがあります。公式サイトのモデル一覧で大きさを確認。", bsize: 17 });
  await k.card(s, { x: 8.8, y: 1.6, w: 3.9, h: 3.6, ic: "FaCode", title: "VS Codeと Python", text: "VS Codeと Python が入っていること。会社PCは社内ルールを先に確認。", bsize: 17 });
  k.bar(s, 0.6, 5.6, 12.1, 0.9, "確認", "三つにチェックできたら、PART Aへ。");

  k.divider("PART A　準備と導入", "STEP 1〜2");

  s = k.content("STEP1　問い：○か×か？", "STEP 1");
  k.trueFalse(s, ["Ollamaは、入力した内容を必ずクラウドに送る。", "Ollamaは、自分のPCの中でモデルを動かせる。", "モデルは、インストールした直後から使える。"]);
  s = k.content("STEP1　答え合わせ", "STEP 1");
  k.trueFalse(s, ["", "", ""], [["×", "Ollamaは、基本的に自分のPCの中で動かします。"], ["○", "ローカルで実行するので、入力を外に送る必要はありません。"], ["×", "モデルを、先にダウンロードしておく必要があります。"]]);

  s = k.content("STEP1　ローカルで動くとは", "STEP 1");
  k.flow(s, [["ダウンロード", "モデルを取り込む"], ["PCで動かす", "メモリで計算する"], ["話しかける", "コマンドや画面で"], ["Pythonから呼ぶ", "同じモデルを使う"]]);

  s = k.content("STEP2　ミッション：Ollamaを入れる", "STEP 2");
  k.mission(s, 0.6, 1.5, 5.6, ["公式サイトからWindows版をダウンロード", "インストーラーを実行（管理者権限は通常不要）", "PowerShellで ollama --version を実行"], 0.78);
  k.cmd(s, 0.6, 4.55, 5.6, ["ollama --version"], 0.9, 14);
  await k.shot(s, 6.6, 1.5, 6.1, 3.9, "ollama --version の結果");
  k.goal(s, 0.6, 6.15, 12.1, "バージョン番号が表示された。");

  s = k.content("STEP2　インストール先と保存先", "STEP 2");
  await k.card(s, { x: 0.6, y: 1.6, w: 3.9, h: 3.8, ic: "FaFolder", title: "プログラム", text: "%LOCALAPPDATA%\\Programs\\Ollama にインストールされる。", bsize: 16 });
  await k.card(s, { x: 4.7, y: 1.6, w: 3.9, h: 3.8, ic: "FaDatabase", title: "モデル", text: "%USERPROFILE%\\.ollama に保存される。変更は OLLAMA_MODELS で。", bsize: 16 });
  await k.card(s, { x: 8.8, y: 1.6, w: 3.9, h: 3.8, ic: "FaPlug", title: "API", text: "http://localhost:11434 で待ち受ける。", bsize: 16 });
  k.bar(s, 0.6, 5.8, 12.1, 0.9, "確認", "場所は公式のWindowsページで最新を確認。");

  k.divider("PART B　お金をかけずに動かす", "STEP 3〜4");

  s = k.content("STEP3　問い：お金がかかるのは？", "STEP 3");
  k.trueFalse(s, ["自分のPCでモデルを動かす範囲では、本体に利用料はかからない。", "クラウド版を使うと、費用が発生する可能性がある。", "電気代やディスク容量は、自分のPCでも必要。"]);
  s = k.content("STEP3　答え合わせ", "STEP 3");
  k.trueFalse(s, ["", "", ""], [["○", "ローカル実行で、本体の利用料はかかりません。"], ["○", "有料の可能性があるので、料金は公式で確認します。"], ["○", "PCの資源は、無料ではありません。"]]);

  s = k.content("STEP3　コストメモを書く", "STEP 3");
  k.sheet(s, ["今使う方法（ローカル／クラウド）", "月の上限の目安（自分で決める）", "確認した公式ページ", "使用量を見る場所"]);

  s = k.content("STEP4　ミッション：モデルを入れて話す", "STEP 4");
  k.mission(s, 0.6, 1.5, 5.6, ["モデルを取り込む（pull）", "話しかける（run）", "終了は /bye と入力"], 0.78);
  k.cmd(s, 0.6, 4.55, 5.6, ["ollama pull llama3.2", "ollama run llama3.2"], 1.1, 14);
  await k.shot(s, 6.6, 1.5, 6.1, 3.9, "会話している画面");
  k.goal(s, 0.6, 6.15, 12.1, "返事が表示され、/bye で終了できた。");

  s = k.content("STEP4　モデルの管理", "STEP 4");
  await k.card(s, { x: 0.6, y: 1.6, w: 3.9, h: 3.6, ic: "FaList", title: "一覧", text: "ollama list で、入っているモデルを確認。", bsize: 17 });
  await k.card(s, { x: 4.7, y: 1.6, w: 3.9, h: 3.6, ic: "FaTrash", title: "削除", text: "ollama rm モデル名。消す前に、本当に要らないか確認。", bsize: 17 });
  await k.card(s, { x: 8.8, y: 1.6, w: 3.9, h: 3.6, ic: "FaHdd", title: "容量", text: "モデルが増えると、ディスクを圧迫します。定期的に確認。", bsize: 17 });
  k.bar(s, 0.6, 5.6, 12.1, 0.9, "ポイント", "使わないモデルは消してかまいません。");

  s = k.content("STEP4　動作確認の4ステップ", "STEP 4");
  k.flow(s, [["入っている", "ollama list に表示"], ["話せる", "run で返事がある"], ["窓口が開く", "11434で応答"], ["確認コマンド", "api/tags を見る"]]);

  k.divider("PART C　使いこなす", "STEP 5〜6");

  s = k.content("STEP5　問い：Pythonから使うと？", "STEP 5");
  k.trueFalse(s, ["Pythonから使うには、公式ライブラリ ollama を pip で入れる。", "モデルは、Pythonから呼ぶ前に pull しておく必要がある。", "ローカルでは、APIキーを必ず取得しなければならない。"]);
  s = k.content("STEP5　答え合わせ", "STEP 5");
  k.trueFalse(s, ["", "", ""], [["○", "pip install ollama で入ります。"], ["○", "モデルがないと、呼び出しが失敗します。"], ["×", "通常、ローカルでは不要です（構成は公式で確認）。"]]);

  s = k.content("STEP5　ミッション：VS Codeで環境を作る", "STEP 5");
  k.mission(s, 0.6, 1.5, 5.6, ["新しいフォルダをVS Codeで開く", "ターミナルで仮想環境を作って有効化", "pip install ollama を実行"], 0.78);
  k.cmd(s, 6.6, 1.5, 6.1, ["python -m venv .venv", ".venv\\Scripts\\activate", "pip install ollama"], 1.5, 14);
  k.bar(s, 6.6, 3.4, 6.1, 1.5, "注意", "会社のPCでは、実行ポリシーの変更は社内ルールを確認。");
  k.goal(s, 0.6, 6.15, 12.1, "pip install が成功し、(.venv) が表示された。");

  s = k.content("STEP5　ミッション：最初のコード", "STEP 5");
  k.mission(s, 0.6, 1.5, 5.6, ["hello.py を作る", "下のコードを貼り付けて実行", "返事が表示されたら完了"], 0.78);
  k.cmd(s, 6.6, 1.5, 6.1, code(["import ollama", "res = ollama.chat(", "    model=\"llama3.2\",", "    messages=[{\"role\": \"user\",", "      \"content\": \"Ollamaとは？一文で\"}])", "print(res[\"message\"][\"content\"])"]), 2.3, 12);
  await k.shot(s, 0.6, 4.4, 5.6, 1.5, "実行結果");
  k.goal(s, 0.6, 6.15, 12.1, "Pythonから、モデルの返事が表示された。");

  s = k.content("STEP6　ミッション：会話を続ける", "STEP 6");
  k.mission(s, 0.6, 1.5, 5.6, ["messages のリストを作る", "返事を append して、次の質問を追加", "2回目の返事で前の文脈が生きているか確認"], 0.78);
  k.cmd(s, 6.6, 1.5, 6.1, code(["messages = []", "messages.append({\"role\": \"user\",", "  \"content\": \"Pythonの特徴は？\"})", "res = ollama.chat(model=\"llama3.2\", messages=messages)", "messages.append(res[\"message\"])"]), 2.3, 12);
  k.bar(s, 6.6, 4.1, 6.1, 1.2, "ポイント", "覚えているのは、リストを渡しているから。");
  k.goal(s, 0.6, 6.15, 12.1, "2回目の質問に、前の話題を踏まえた返事があった。");

  s = k.content("STEP6　ストリーミングと接続先", "STEP 6");
  await k.card(s, { x: 0.6, y: 1.6, w: 3.9, h: 3.8, ic: "FaStream", title: "stream=True", text: "返事を少しずつ表示できる。", bsize: 17 });
  await k.card(s, { x: 4.7, y: 1.6, w: 3.9, h: 3.8, ic: "FaNetworkWired", title: "接続先", text: "ollama.Client(host=...) で指定。", bsize: 17 });
  await k.card(s, { x: 8.8, y: 1.6, w: 3.9, h: 3.8, ic: "FaLock", title: "習慣", text: "どのPCに送っているか、必ず確認する。", bsize: 17 });
  k.bar(s, 0.6, 5.8, 12.1, 0.9, "注意", "ローカル以外へ送るなら、情報管理の承認を先に。");

  k.divider("PART D　守る・直す・仕上げる", "STEP 7〜8");

  s = k.content("STEP7　問い：困ったら何を見る？", "STEP 7");
  k.trueFalse(s, ["Ollamaが動かないとき、最初に起動しているかを確認する。", "ポート11434に繋がるかどうかは、後回しでよい。", "モデル名のスペルは、結果に影響しない。"]);
  s = k.content("STEP7　答え合わせ", "STEP 7");
  k.trueFalse(s, ["", "", ""], [["○", "起動していないと、どのコードも応答しません。"], ["×", "接続できるかは、最初に確かめる点です。"], ["×", "スペルが違うと、モデルが見つからず失敗します。"]]);

  s = k.content("STEP7　切り分けフロー", "STEP 7");
  const flowSteps = ["Ollamaは起動しているか", "モデル名は正しいか（list）", "pull は完了しているか", "11434に繋がるか（curl）", "仮想環境は有効か（.venv）", "パッケージは入っているか"];
  flowSteps.forEach((t, i) => {
    const x = 0.6 + (i % 2) * 6.1, y = 1.5 + Math.floor(i / 2) * 1.7;
    const last = i === flowSteps.length - 1;
    s.addShape(k.pres.shapes.ROUNDED_RECTANGLE, { x, y, w: 5.9, h: 1.4, fill: { color: last ? C.accent3 : C.background2 }, rectRadius: 0.12 });
    k.txt(s, String(i + 1), { x: x + 0.3, y, w: 0.8, h: 1.4, fontSize: 30, bold: true, color: last ? C.text1 : C.accent1, valign: "middle", fontFace: k.THEME.headFontFace });
    k.txt(s, t, { x: x + 1.2, y, w: 4.5, h: 1.4, fontSize: 18, bold: true, color: last ? C.text1 : C.accent1, valign: "middle" });
  });

  s = k.content("STEP7　症状と直し方の早見表", "STEP 7");
  s.addTable([
    [{ text: "症状", options: { bold: true, color: C.background1, fill: { color: C.accent1 }, valign: "middle" } }, { text: "よくある原因", options: { bold: true, color: C.background1, fill: { color: C.accent1 }, valign: "middle" } }, { text: "直し方", options: { bold: true, color: C.background1, fill: { color: C.accent1 }, valign: "middle" } }],
    ["コマンドが見つからない", "インストール後、PowerShellを開き直していない", "開き直す。それでもだめなら再インストール"],
    ["ConnectionError", "Ollamaが起動していない", "タスクトレイのOllamaを確認して起動"],
    ["モデルが見つからない", "名前のスペル違い／pull未完了", "ollama list で名前を確認し、pull し直す"],
    ["応答がとても遅い", "PCの資源（メモリ・GPU）不足", "小さいモデルに替える。他のアプリを閉じる"],
  ], { x: 0.6, y: 1.5, w: 12.1, colW: [3.4, 4.4, 4.3], rowH: [0.6, 0.9, 0.9, 0.9, 0.9], fontSize: 15, color: C.text1, border: { type: "solid", color: "E0C8CC", pt: 1 }, fontFace: "Calibri", margin: [0, 0.15, 0, 0.15] });

  s = k.content("STEP8　問い：機密情報はどう扱う？", "STEP 8");
  k.trueFalse(s, ["ローカル実行なら、保存されたデータも含めて安全と断言できる。", "社内ルールを確認せずに、業務データを入力してよい。", "スクショに秘密情報が写ったら、塗りつぶしてから共有する。"]);
  s = k.content("STEP8　答え合わせ", "STEP 8");
  k.trueFalse(s, ["", "", ""], [["×", "保存やログは確認が必要。安全と断言しない。"], ["×", "社内規程に反する可能性があるので、必ず確認。"], ["○", "秘密情報は、写さないか、塗りつぶすのが鉄則。"]]);

  s = k.content("STEP8　安全3原則", "STEP 8");
  await k.card(s, { x: 0.6, y: 1.6, w: 3.9, h: 3.8, ic: "FaBook", title: "① 社内ルール", text: "使ってよい情報と、使い方を先に確認する。", bsize: 17 });
  await k.card(s, { x: 4.7, y: 1.6, w: 3.9, h: 3.8, ic: "FaLock", title: "② 秘密情報", text: "入力しない、またはマスクしてから使う。", bsize: 17 });
  await k.card(s, { x: 8.8, y: 1.6, w: 3.9, h: 3.8, ic: "FaCheckCircle", title: "③ 人が確認", text: "AIの出力は誤りを含みうる。事実は一次情報で確かめる。", bsize: 17 });
  k.bar(s, 0.6, 5.8, 12.1, 0.9, "鉄則", "ローカルでも、入力と共有は慎重に。");

  s = k.content("STEP8　総合演習：業務に当てはめる", "STEP 8");
  k.sheet(s, ["使う場面（業務の一つ）", "目的", "使うモデル", "入力してよい情報", "出力を確認する人", "次の一歩"], 1.45, 0.82);

  s = k.content("確認テスト");
  const quiz = [["Q1　Ollamaを入れるとき、管理者権限は？", "A 必ず必要　B 通常は不要　C クラウド契約が必要"], ["Q2　Pythonからモデルを呼ぶ前にすることは？", "A モデルを先に pull しておく　B APIキーを取得　C 別のAIに替える"], ["Q3　Ollamaが応答しないときの最初の確認は？", "A PCを初期化　B 別のAIサービスに変える　C 起動と11434への接続を確認"], ["Q4　業務データを入力する前にすることは？", "A 社内ルールを確認し、入力してよいか判断　B まず入力してから考える　C 他人のPCで試す"], ["Q5　スクショに秘密情報が写ったら？", "A そのまま共有　B ファイル名だけ変える　C 塗りつぶしてから共有"]];
  quiz.forEach(([q, o], i) => {
    const y = 1.5 + i * 1.05;
    s.addShape(k.pres.shapes.ROUNDED_RECTANGLE, { x: 0.6, y, w: 12.1, h: 0.9, fill: { color: C.background2 }, rectRadius: 0.1 });
    k.txt(s, q, { x: 0.9, y: y + 0.05, w: 11.5, h: 0.4, fontSize: 17, bold: true, color: C.accent1, valign: "middle" });
    k.txt(s, o, { x: 0.9, y: y + 0.45, w: 11.5, h: 0.4, fontSize: 15, color: C.text1, valign: "middle" });
  });

  s = k.content("確認テスト　答え");
  const ans = [["Q1", "B", "通常は不要。ホームフォルダに入ります。"], ["Q2", "A", "モデルがないと呼び出しが失敗します。"], ["Q3", "C", "起動と接続の確認が最初の切り分けです。"], ["Q4", "A", "社内規程を確認してから判断します。"], ["Q5", "C", "秘密情報は塗りつぶしてから共有します。"]];
  ans.forEach(([q, a, e], i) => {
    const y = 1.5 + i * 1.05;
    s.addShape(k.pres.shapes.OVAL, { x: 0.9, y: y + 0.15, w: 0.6, h: 0.6, fill: { color: C.accent1 } });
    k.txt(s, a, { x: 0.9, y: y + 0.15, w: 0.6, h: 0.6, fontSize: 20, bold: true, color: C.background1, align: "center", valign: "middle" });
    k.txt(s, `${q}　${e}`, { x: 1.8, y, w: 10.8, h: 0.9, fontSize: 18, valign: "middle" });
  });

  s = k.content("修了チェックリスト");
  const checks = ["Ollamaを入れて、ollama --version が表示された", "pull と run で、モデルと話せた", "保存先（.ollama）と、容量を確認した", "利用料の上限を、自分で決めた", "VS Codeで仮想環境を作り、ollama を入れた", "Pythonから返事を表示できた", "messages を使って、2回目の質問をした", "社内ルールと、秘密情報の扱いを確認した"];
  checks.forEach((c, i) => {
    const y = 1.45 + i * 0.66;
    s.addShape(k.pres.shapes.RECTANGLE, { x: 0.8, y: y + 0.12, w: 0.36, h: 0.36, fill: { color: C.background1 }, line: { color: C.accent1, width: 2 } });
    k.txt(s, c, { x: 1.4, y, w: 11, h: 0.6, fontSize: 18, valign: "middle" });
  });

  s = k.content("次のステップ");
  await k.card(s, { x: 0.6, y: 1.6, w: 3.9, h: 3.8, ic: "FaBook", title: "公式を読む", text: "ollama.com と docs.ollama.com で最新の手順を確認。", bsize: 17 });
  await k.card(s, { x: 4.7, y: 1.6, w: 3.9, h: 3.8, ic: "FaCode", title: "小さく作る", text: "業務の一つを、Pythonで小さく試す。", bsize: 17 });
  await k.card(s, { x: 8.8, y: 1.6, w: 3.9, h: 3.8, ic: "FaRedo", title: "続ける", text: "コストメモを毎月見直し、上限を守る。", bsize: 17 });
  k.bar(s, 0.6, 5.8, 12.1, 0.9, "公式", "Windowsの手順・モデル一覧は、公式の最新ページが正です。");

  s = k.content("公開前の注意");
  k.bar(s, 0.6, 1.6, 12.1, 1.3, "この講座について", "公式とは独立した解説です。版によって画面や手順は変わります。");
  k.txt(s, "・料金・無料の範囲・モデル名・コマンドは、必ず公式の最新ページで確認してください。\n・スクショに、APIキーや個人情報が写らないように塗りつぶしてください。\n・会社のPCで行うときは、社内ルールを先に確認してください。", { x: 0.9, y: 3.3, w: 11.5, h: 2.5, fontSize: 19, color: C.text1, valign: "top" });

  k.applyNotes(NOTES);
  await k.save(out);
  console.log("saved", out, "slides=", k.pres.slides.length);
})().catch((e) => { console.error(e); process.exit(1); });
