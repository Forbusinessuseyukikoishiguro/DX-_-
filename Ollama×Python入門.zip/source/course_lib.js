// handson-course-builder: 自習/講義/収録の3モードに使えるUdemy講座PPTの共通部品
// 使い方: const L = require("./course_lib.js"); const k = await L.create({...}); k.content("題名","STEP 1") ...
// 必須: pptxgenjs, react, react-dom, react-icons, sharp（npmグローバル想定。NODE_PATH=$(npm root -g) node xxx.js で実行）
const pptxgen = require("pptxgenjs");
const React = require("react");
const RDS = require("react-dom/server");
const sharp = require("sharp");
const fa = require("react-icons/fa");

const DEFAULT_THEME = {
  name: "UsausaRose", headFontFace: "Bookman Old Style", bodyFontFace: "Calibri",
  colors: { dk1: "2B2B2B", lt1: "FFFFFF", dk2: "3B1727", lt2: "F4DEE0", accent1: "6D2E46", accent2: "A26769", accent3: "C9A227", accent4: "3E7C8F", accent5: "2C3E50", accent6: "8A6410", hlink: "6D2E46", folHlink: "A26769" },
};
exports.DEFAULT_THEME = DEFAULT_THEME;

exports.create = async function create(opts = {}) {
  const THEME = Object.assign({}, DEFAULT_THEME, opts.theme || {});
  const footer = opts.footer || "講座名 ｜ 講師名";
  const pres = new pptxgen();
  pres.layout = "LAYOUT_WIDE"; // 13.33 x 7.5 in
  pres.theme = { headFontFace: THEME.headFontFace, bodyFontFace: THEME.bodyFontFace };
  pres.title = opts.title || "講座"; pres.author = opts.author || "";
  const C = pres.SchemeColor; const W = 13.33;
  const BG = THEME.colors.accent1, DARK = THEME.colors.dk2; // マスター背景は16進のみ可

  const cache = {};
  async function icon(name, hex = "FFFFFF") {
    const key = name + hex; if (cache[key]) return cache[key];
    const svg = RDS.renderToStaticMarkup(React.createElement(fa[name], { color: "#" + hex, size: 256 }));
    return (cache[key] = "image/png;base64," + (await sharp(Buffer.from(svg)).png().toBuffer()).toString("base64"));
  }

  pres.defineSlideMaster({ title: "TITLE", background: { color: BG }, objects: [{ rect: { x: 0, y: 5.9, w: W, h: 1.6, fill: { color: DARK } } }],
    placeholders: [{ placeholder: { options: { name: "title", type: "title", x: 0.9, y: 1.4, w: 11.5, h: 2.4 }, text: "" } }, { placeholder: { options: { name: "body", type: "body", x: 0.9, y: 3.95, w: 11.5, h: 1.4 }, text: "" } }] });
  pres.defineSlideMaster({ title: "SECTION", background: { color: BG },
    placeholders: [{ placeholder: { options: { name: "title", type: "title", x: 1.0, y: 2.6, w: 11.3, h: 1.6 }, text: "" } }, { placeholder: { options: { name: "body", type: "body", x: 1.0, y: 4.3, w: 11.3, h: 1.2 }, text: "" } }] });
  pres.defineSlideMaster({ title: "CONTENT", background: { color: "FFFFFF" },
    objects: [{ text: { text: footer, options: { x: 0.6, y: 7.05, w: 6, h: 0.3, fontSize: 10, color: "8A6A72", fontFace: "Calibri", margin: 0 } } }],
    slideNumber: { x: 12.2, y: 7.05, w: 0.6, h: 0.3, fontSize: 10, color: "8A6A72", align: "right", margin: 0 },
    placeholders: [{ placeholder: { options: { name: "title", type: "title", x: 0.6, y: 0.4, w: 10.4, h: 0.9 }, text: "" } }] });
  // ※ プレースホルダの書式はLibreOfficeで効かないため、各スライドで位置・書式を必ず明示する（下の関数が実施済み）

  let curSection = "";
  const k = { pres, C, W, THEME, icon };
  k.section = (t) => { curSection = t; pres.addSection({ title: t }); };
  k.txt = (s, text, o) => s.addText(text, Object.assign({ fontSize: 16, color: C.text1, margin: 0, valign: "top", isTextBox: true }, o));

  k.titleSlide = async (title, sub, brand) => {
    const s = pres.addSlide({ masterName: "TITLE", sectionTitle: curSection });
    s.addText(title, { placeholder: "title", x: 0.9, y: 1.4, w: 11.5, h: 2.4, fontFace: THEME.headFontFace, fontSize: 40, bold: true, color: C.background1, valign: "middle", margin: 0 });
    s.addText(sub, { placeholder: "body", x: 0.9, y: 3.95, w: 11.5, h: 1.4, fontSize: 20, color: C.background2, valign: "top", margin: 0 });
    k.txt(s, brand || "", { x: 0.9, y: 6.45, w: 6, h: 0.5, fontSize: 18, bold: true, color: C.background2, valign: "middle" });
    s.addImage({ data: await icon("FaRocket", THEME.colors.accent3), x: 11.6, y: 6.3, w: 0.8, h: 0.8, altText: "" });
    return s;
  };
  k.divider = (title, sub) => {
    const s = pres.addSlide({ masterName: "SECTION", sectionTitle: curSection });
    s.addText(title, { placeholder: "title", x: 1.0, y: 2.6, w: 11.3, h: 1.6, fontFace: THEME.headFontFace, fontSize: 40, bold: true, color: C.background1, valign: "middle", margin: 0 });
    s.addText(sub, { placeholder: "body", x: 1.0, y: 4.3, w: 11.3, h: 1.2, fontSize: 20, color: C.background2, valign: "top", margin: 0 });
    return s;
  };
  // タイトルは1行（全角約20字）に収める。長いと2行になりSTEPピルと重なる
  k.content = (title, step) => {
    const s = pres.addSlide({ masterName: "CONTENT", sectionTitle: curSection });
    s.addText(title, { placeholder: "title", x: 0.6, y: 0.4, w: 10.4, h: 0.9, fontFace: THEME.headFontFace, fontSize: 34, bold: true, color: C.accent1, valign: "middle", margin: 0 });
    if (step) {
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 11.3, y: 0.55, w: 1.45, h: 0.5, fill: { color: C.accent3 }, rectRadius: 0.25 });
      s.addText(step, { x: 11.3, y: 0.55, w: 1.45, h: 0.5, fontSize: 14, bold: true, color: C.text1, align: "center", valign: "middle", margin: 0, isTextBox: true });
    }
    return s;
  };

  // カード（アイコン＋見出し＋本文）。濃い背景のカードは tcolor/bcolor を必ず明示する
  k.card = async (s, o) => {
    const { x, y, w, h, title, text, ic, fill = C.background2, ibg = C.accent1, tsize = 18, bsize = 15, tcolor = C.accent1, bcolor = C.text1 } = o;
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, fill: { color: fill }, rectRadius: 0.12, line: { color: fill, width: 0 } });
    let tx = x + 0.3;
    if (ic) {
      s.addShape(pres.shapes.OVAL, { x: x + 0.25, y: y + 0.25, w: 0.65, h: 0.65, fill: { color: ibg } });
      s.addImage({ data: await icon(ic), x: x + 0.4, y: y + 0.4, w: 0.35, h: 0.35, altText: "" });
      tx = x + 1.05;
    }
    k.txt(s, title, { x: tx, y: y + 0.22, w: w - (tx - x) - 0.25, h: 0.7, fontSize: tsize, bold: true, color: tcolor, valign: "middle" });
    if (text) k.txt(s, text, { x: x + 0.3, y: y + 1.0, w: w - 0.6, h: h - 1.15, fontSize: bsize, color: bcolor });
  };
  k.pill = (s, x, y, w, h, text, fill, color, size = 14) => {
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, fill: { color: fill }, rectRadius: h / 2 });
    k.txt(s, text, { x, y, w, h, fontSize: size, bold: true, color, align: "center", valign: "middle" });
  };
  // コマンド枠。長い行は fs を下げるか行を分ける（枠からはみ出さない確認を必ず）
  k.cmd = (s, x, y, w, lines, h, fs = 14) => {
    const hh = h || 0.2 + lines.length * 0.42;
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h: hh, fill: { color: C.text2 }, rectRadius: 0.08 });
    s.addText(lines.map((l, i) => ({ text: l, options: { breakLine: i < lines.length - 1 } })), { x: x + 0.25, y, w: w - 0.5, h: hh, fontFace: "Courier New", fontSize: fs, color: "F4DEE0", valign: "middle", margin: 0, isTextBox: true });
    return hh;
  };
  // スクショ貼り付け枠（受講者が自分の画面を貼る）
  k.shot = async (s, x, y, w, h, label) => {
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, fill: { color: "FAFAFA" }, line: { color: "9A9A9A", width: 1.5, dashType: "dash" }, rectRadius: 0.1 });
    s.addImage({ data: await icon("FaCamera", "8A8A8A"), x: x + w / 2 - 0.25, y: y + h / 2 - 0.65, w: 0.5, h: 0.5, altText: "" });
    k.txt(s, "ここに自分の画面を貼る", { x, y: y + h / 2 - 0.05, w, h: 0.35, fontSize: 14, bold: true, color: "6B6B6B", align: "center" });
    k.txt(s, label, { x: x + 0.15, y: y + h / 2 + 0.3, w: w - 0.3, h: 0.5, fontSize: 12, color: "6B6B6B", align: "center" });
  };
  // ミッション（番号つき手順）。st=手順の間隔。手順が多いときは小さくして下の部品と重ねない
  k.mission = (s, x, y, w, items, st = 0.78) => {
    k.pill(s, x, y, 1.6, 0.42, "MISSION", C.accent3, C.text1, 14);
    items.forEach((t, i) => {
      s.addShape(pres.shapes.OVAL, { x, y: y + 0.65 + i * st, w: 0.42, h: 0.42, fill: { color: C.accent1 } });
      k.txt(s, String(i + 1), { x, y: y + 0.65 + i * st, w: 0.42, h: 0.42, fontSize: 14, bold: true, color: C.background1, align: "center", valign: "middle" });
      k.txt(s, t, { x: x + 0.6, y: y + 0.6 + i * st, w: w - 0.6, h: 0.7, fontSize: 16, valign: "middle" });
    });
  };
  // 「できた！の目安」バー（ミッションの合格条件）
  k.goal = (s, x, y, w, text) => {
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h: 0.75, fill: { color: C.accent1 }, rectRadius: 0.1 });
    k.txt(s, [{ text: "できた！の目安　", options: { bold: true, color: C.accent3 } }, { text, options: { color: C.background1 } }], { x: x + 0.3, y, w: w - 0.6, h: 0.75, fontSize: 15, valign: "middle" });
  };
  // 強調バー（迷ったら／鉄則／お金の視点 など）
  k.bar = (s, x, y, w, h, label, text) => {
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, fill: { color: C.accent1 }, rectRadius: 0.12 });
    k.txt(s, [{ text: label + "　", options: { bold: true, color: C.accent3 } }, { text, options: { color: C.background1 } }], { x: x + 0.35, y, w: w - 0.7, h, fontSize: 18, valign: "middle" });
  };
  // ○×問題（answers を渡さなければ問い、配列 [["○","解説"],...] を渡せば答え合わせ）
  k.trueFalse = (s, qs, answers) => {
    qs.forEach((q, i) => {
      const y = 1.6 + i * 1.3;
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 0.6, y, w: 12.1, h: 1.1, fill: { color: C.background2 }, rectRadius: 0.1 });
      if (!answers) {
        k.txt(s, "Q" + (i + 1), { x: 0.9, y, w: 0.9, h: 1.1, fontSize: 26, bold: true, color: C.accent1, valign: "middle", fontFace: THEME.headFontFace });
        k.txt(s, q, { x: 1.9, y, w: 8.2, h: 1.1, fontSize: 20, valign: "middle" });
        [["○", 10.5], ["×", 11.7]].forEach(([m, mx]) => {
          s.addShape(pres.shapes.OVAL, { x: mx, y: y + 0.2, w: 0.7, h: 0.7, fill: { color: C.background1 }, line: { color: C.accent1, width: 2 } });
          k.txt(s, m, { x: mx, y: y + 0.2, w: 0.7, h: 0.7, fontSize: 24, bold: true, color: C.accent1, align: "center", valign: "middle" });
        });
      } else {
        const a = answers[i];
        s.addShape(pres.shapes.OVAL, { x: 0.9, y: y + 0.2, w: 0.7, h: 0.7, fill: { color: a[0] === "○" ? C.accent1 : C.accent4 } });
        k.txt(s, a[0], { x: 0.9, y: y + 0.2, w: 0.7, h: 0.7, fontSize: 24, bold: true, color: C.background1, align: "center", valign: "middle" });
        k.txt(s, a[1], { x: 1.9, y, w: 10.6, h: 1.1, fontSize: 17, valign: "middle" });
      }
    });
  };
  // 書き込みシート（左=項目、右=空欄。受講者がPPT上に入力する）
  k.sheet = (s, rows, y0 = 1.6, rowH = 0.85) => {
    s.addTable(rows.map((r) => [
      { text: r, options: { bold: true, color: C.background1, fill: { color: C.accent1 }, fontSize: 16, valign: "middle" } },
      { text: "", options: { fill: { color: C.background2 }, fontSize: 16, valign: "middle" } },
    ]), { x: 0.6, y: y0, w: 12.1, colW: [4.6, 7.5], rowH, border: { type: "solid", color: "FFFFFF", pt: 3 }, fontFace: "Calibri", margin: [0, 0.2, 0, 0.2] });
  };
  // 手順フロー（横並び最大4）。steps = [["見出し","説明"],...]
  k.flow = (s, steps, y = 1.7) => steps.forEach((f, i) => {
    const x = 0.6 + i * 3.1;
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w: 2.85, h: 2.4, fill: { color: i % 2 ? C.accent2 : C.accent1 }, rectRadius: 0.12 });
    k.txt(s, String(i + 1), { x: x + 0.25, y: y + 0.15, w: 0.8, h: 0.7, fontSize: 30, bold: true, color: C.accent3, fontFace: THEME.headFontFace, valign: "middle" });
    k.txt(s, f[0], { x: x + 0.25, y: y + 0.85, w: 2.4, h: 0.5, fontSize: 18, bold: true, color: C.background1, valign: "middle" });
    k.txt(s, f[1], { x: x + 0.25, y: y + 1.4, w: 2.4, h: 0.9, fontSize: 14, color: C.background1 });
  });

  // 台本ノートを全スライドに付ける。notes = [{t, m:[話す分,実習分], say:[], act:[], memo:[]}]
  k.applyNotes = (notes) => {
    const sl = pres.slides;
    if (sl.length !== notes.length) throw new Error(`スライド${sl.length}枚 と 台本${notes.length}件が不一致`);
    sl.forEach((x, i) => {
      const n = notes[i];
      const p = [`【講師用ノート】${n.t}（話す${n.m[0]}分／実習${n.m[1]}分）`, ""];
      n.say.forEach((l) => p.push(`「${l}」`)); n.act.forEach((l) => p.push(l)); n.memo.forEach((l) => p.push(`メモ：${l}`));
      x.addNotes(p.join("\n"));
    });
  };
  k.save = async (file, applyThemePath) => {
    await pres.writeFile({ fileName: file });
    const { applyTheme } = require(applyThemePath || "/mnt/skills/public/pptx/scripts/apply_theme.js");
    await applyTheme(file, THEME); // テーマ色を書き込む（しないとスキームカラーがOffice標準色になる）
  };
  return k;
};
