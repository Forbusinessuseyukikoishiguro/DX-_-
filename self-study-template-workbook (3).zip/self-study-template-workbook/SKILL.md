---
name: self-study-template-workbook
description: 仕様書・業務テンプレート一式（Notion／Word／Zip）と、購入者が一人で学べる自習ワークブックPPT（架空事例1本・記入例・ワーク・確認テスト付き）をセットで作るSkill。「〇〇向けテンプレ一式作って」「Notionで仕様書テンプレ」「一人で買って学べる資料にして」「自習用に」「販売用ワークブック」「DX版／AIコンサル版も同じように」などの依頼で必ず使う。うさうさ研修工房のRose Deckブランド準拠。
---

# 自習ワークブック × テンプレート一式 制作スキル

「テンプレート一式」と「それを一人で使いこなせるようになる自習資料」を、同じ型で繰り返し作るための手順書です。

## 作るもの（4点セット）
1. **Notionテンプレート一式**：親ページ＋サブページ（文書7点前後）＋データベース1点（変更管理表／リスク台帳など）
2. **Markdown Zip**：Notion取り込み用の元データ（.md＋DB用.csv＋README）
3. **Word版**：全テンプレを1冊に統合した記入用docx（必要な時のみ）
4. **自習ワークブックPPT**：講師なしで学べる18枚前後（本Skillの中心）

依頼が「PPTだけ」「Notionだけ」なら該当部分だけ作る。迷ったら質問せず、直近の依頼の範囲で実行する。

## 進め方
1. **対象と型を決める**：読者（DXエンジニア／AIコンサル／その他）と、文書の並び（上流→下流）を `reference/テンプレート一式の設計.md` で決める
2. **Notionに作る**：親ページ（draft）→サブページ→データベース＋サンプル1行。作成後に親ページURLを案内し、移動先を聞く
3. **Zip／Word**：必要なら同内容をmd／docxで出す（docxは docx スキル、pptxは pptx スキルに従う）
4. **自習ワークブック**：`reference/自習ワークブック設計ガイド.md` に従い、spec.json を書いて `assets/build_workbook.js` で生成する
   - 実行：`node assets/build_workbook.js spec.json`（pptxgenjs が必要）
   - 見本：`assets/example_spec_ai.json`（AIコンサル版・18枚）
5. **検証**：`reference/品質チェックリスト.md` を全項目確認（数値の検算・架空明記・画像で目視）
6. 出力は `/mnt/user-data/outputs/` に置き、present_files で渡す

## 守ること
- 記入例の会社名・数字は**必ず架空と明記**し、実在の統計のように書かない
- 一般論を述べる箇所は「特定の統計に基づくものではない」旨を添える（根拠のない数字・割合を書かない）
- 法務・個人情報・契約の判断は代替しない旨の注意書きを入れる
- 計算例は自分で検算してから載せる
- 自習版は「解説→記入例→ワーク」を各ステップで必ず1セットにする
- 余分な質問をしない。依頼が短くても、直近の文脈から範囲を判断して最後まで作る

## 生成スクリプトの補足
- spec.json の `outFile` に出力パスを書く。`type` は title / cards / flow / twocol / step / eval / table / list / summary
- pptxgenjs が見つからない時は `NODE_PATH=$(npm root -g) node assets/build_workbook.js spec.json`
- 見本 `assets/example_spec_ai.json` をコピーして、題材・ステップ・数字を差し替えるのが最短
- 生成後は必ず validate → PDF → 画像化して目視する（pptx スキルの手順）
