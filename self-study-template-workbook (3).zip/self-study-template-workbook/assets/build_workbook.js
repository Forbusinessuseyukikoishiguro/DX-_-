// 使い方: node build_workbook.js spec.json   （pptxgenjs が必要）
const fs = require("fs");
const pptxgen = require("pptxgenjs");
const spec = JSON.parse(fs.readFileSync(process.argv[2], "utf-8"));
const C = Object.assign({ BERRY:"6D2E46", DUSTY:"A26769", GOLD:"C9A227", BLUSH:"F4DEE0", WHITE:"FFFFFF", DARK:"3A2A2E" }, spec.colors||{});
const {BERRY,DUSTY,GOLD,BLUSH,WHITE,DARK} = C;
const TF = spec.titleFont || "Bookman Old Style", BF = spec.bodyFont || "Calibri";
const BRAND = spec.brand || "うさうさ研修工房";
const pres = new pptxgen(); pres.layout = "LAYOUT_WIDE";
let N = 0;
const mk = (bg=WHITE)=>{ const s=pres.addSlide(); s.background={color:bg}; N++; return s; };
const pn = s=>{ if(N>1) s.addText(String(N),{x:12.6,y:7.05,w:0.5,h:0.3,fontFace:BF,fontSize:10,color:DUSTY,align:"right",margin:0}); };
const tag = (s,t)=>s.addText(t||"",{x:0.6,y:0.3,w:9,h:0.35,fontFace:BF,fontSize:12,bold:true,color:DUSTY,margin:0,charSpacing:2});
const ttl = (s,t,sz=26)=>s.addText(t,{x:0.6,y:0.68,w:12.1,h:0.7,fontFace:TF,fontSize:sz,bold:true,color:BERRY,margin:0});
const txt = (s,t,o)=>s.addText(t,Object.assign({fontFace:BF,fontSize:13,color:DARK,margin:0,valign:"top"},o));
const bullets = (s,items,o)=>s.addText(items.map((t,i)=>({text:t,options:{bullet:{indent:14},breakLine:i<items.length-1,paraSpaceAfter:6}})),Object.assign({fontFace:BF,fontSize:13,color:DARK,margin:0,valign:"top"},o));
const card = (s,x,y,w,h,head,fill=BLUSH,hc=BERRY)=>{
  s.addShape(pres.shapes.ROUNDED_RECTANGLE,{x,y,w,h,rectRadius:0.08,fill:{color:fill},line:{type:"none"}});
  if(head) s.addText(head,{x:x+0.25,y:y+0.15,w:w-0.5,h:0.4,fontFace:BF,fontSize:15,bold:true,color:hc,margin:0});
};
const work = (s,t)=>{ if(!t) return;
  s.addShape(pres.shapes.ROUNDED_RECTANGLE,{x:0.6,y:6.0,w:12.1,h:0.95,rectRadius:0.08,fill:{color:WHITE},line:{color:GOLD,width:2}});
  s.addText("✎ ワーク",{x:0.85,y:6.0,w:1.3,h:0.95,fontFace:BF,fontSize:14,bold:true,color:GOLD,valign:"middle",margin:0});
  s.addText(t,{x:2.2,y:6.0,w:10.3,h:0.95,fontFace:BF,fontSize:13,color:DARK,valign:"middle",margin:0});
};
const table = (s,rows,o)=>{
  const body = rows.map((r,ri)=>r.map(c=>({text:c,options:{bold:ri===0,color:ri===0?WHITE:DARK,fill:{color:ri===0?BERRY:(ri%2?WHITE:BLUSH)},fontFace:BF,fontSize:12,valign:"middle"}})));
  s.addTable(body,Object.assign({border:{type:"solid",pt:0.5,color:"E5D5D9"},margin:[0.04,0.08,0.04,0.08]},o));
};

const T = {
  title(d){ const s=mk(BERRY);
    s.addShape(pres.shapes.OVAL,{x:10.6,y:-1.8,w:5.5,h:5.5,fill:{color:DUSTY,transparency:55},line:{type:"none"}});
    s.addShape(pres.shapes.OVAL,{x:-1.6,y:5.2,w:4.2,h:4.2,fill:{color:GOLD,transparency:70},line:{type:"none"}});
    txt(s,d.kicker||"一人で学べる 自習ワークブック",{x:0.9,y:2.0,w:10,h:0.6,fontFace:TF,fontSize:20,color:BLUSH});
    txt(s,d.title,{x:0.9,y:2.6,w:11.5,h:1.0,fontFace:TF,fontSize:42,bold:true,color:WHITE});
    txt(s,d.subtitle||"",{x:0.9,y:3.7,w:11.5,h:0.6,fontFace:TF,fontSize:24,color:WHITE});
    txt(s,d.tagline||"",{x:0.9,y:4.6,w:11,h:0.6,fontSize:15,italic:true,color:BLUSH});
    txt(s,BRAND,{x:0.9,y:6.7,w:6,h:0.4,fontSize:13,color:GOLD}); },
  cards(d){ const s=mk(); tag(s,d.tag); ttl(s,d.title);
    const n=d.cards.length, w=(12.1-(n-1)*0.25)/n, dark=d.dark;
    d.cards.forEach((c,i)=>{ const x=0.6+i*(w+0.25);
      card(s,x,1.6,w,d.note?2.4:2.9,c.h,dark?(i%2?DUSTY:BERRY):BLUSH,dark?WHITE:BERRY);
      txt(s,c.t,{x:x+0.25,y:2.25,w:w-0.5,h:1.6,fontSize:14,color:dark?WHITE:DARK}); });
    if(d.note){ card(s,0.6,4.3,12.1,1.5,d.note.h); (d.note.bullets?bullets:txt)(s,d.note.bullets||d.note.t,{x:0.85,y:4.8,w:11.6,h:0.95}); }
    if(d.footer) txt(s,d.footer,{x:0.6,y:6.2,w:12.1,h:0.5,fontSize:13,italic:true,color:BERRY});
    pn(s); },
  flow(d){ const s=mk(); tag(s,d.tag); ttl(s,d.title);
    const n=d.steps.length, w=(12.1-(n-1)*0.25)/n;
    d.steps.forEach((t,i)=>{ const x=0.6+i*(w+0.25);
      s.addShape(pres.shapes.ROUNDED_RECTANGLE,{x,y:1.9,w,h:1.5,rectRadius:0.1,fill:{color:i%2?DUSTY:BERRY},line:{type:"none"}});
      s.addText(t,{x,y:1.9,w,h:1.5,align:"center",valign:"middle",fontFace:BF,fontSize:15,bold:true,color:WHITE,margin:0}); });
    card(s,0.6,3.8,12.1,2.1,d.box.h); bullets(s,d.box.bullets,{x:0.85,y:4.3,w:11.6,h:1.5}); pn(s); },
  twocol(d){ const s=mk(); tag(s,d.tag); ttl(s,d.title);
    const h=d.work?4.3:4.4;
    card(s,0.6,1.5,d.lw||6.0,h,d.left.h); bullets(s,d.left.bullets,{x:0.85,y:2.1,w:(d.lw||6.0)-0.5,h:h-0.7});
    const rx=0.6+(d.lw||6.0)+0.3, rw=12.7-rx;
    card(s,rx,1.5,rw,h,d.right.h,DUSTY,WHITE);
    if(d.right.bullets) bullets(s,d.right.bullets,{x:rx+0.25,y:2.1,w:rw-0.5,h:h-0.7,color:WHITE});
    if(d.right.t) txt(s,d.right.t,{x:rx+0.25,y:2.1,w:rw-0.5,h:2.0,color:WHITE,fontSize:14});
    if(d.right.note) txt(s,d.right.note,{x:rx+0.25,y:4.4,w:rw-0.5,h:1.0,color:BLUSH,italic:true});
    work(s,d.work); pn(s); },
  step(d){ const s=mk(); tag(s,d.tag); ttl(s,d.title);
    card(s,0.6,1.5,4.6,4.3,d.leftHead||"何を書くか"); bullets(s,d.left,{x:0.85,y:2.1,w:4.1,h:3.6});
    txt(s,d.rightHead||"記入例（架空）",{x:5.5,y:1.5,w:7.2,h:0.4,fontSize:15,bold:true,color:BERRY});
    table(s,d.rows,{x:5.5,y:1.95,w:7.2,colW:d.colW}); work(s,d.work); pn(s); },
  eval(d){ const s=mk(); tag(s,d.tag); ttl(s,d.title);
    card(s,0.6,1.5,5.2,4.3,d.leftHead); txt(s,d.intro,{x:0.85,y:2.05,w:4.7,h:0.4});
    table(s,d.matrix,{x:0.85,y:2.5,w:4.7,colW:d.matrixColW||[1.9,1.4,1.4]});
    txt(s,d.legend,{x:0.85,y:4.0,w:4.7,h:0.9,fontSize:12,italic:true,color:DUSTY});
    card(s,6.1,1.5,6.6,4.3,d.rightHead);
    table(s,d.rows,{x:6.35,y:2.05,w:6.1,colW:d.colW||[1.9,2.8,1.4]});
    txt(s,d.reading,{x:6.35,y:4.1,w:6.1,h:1.5}); work(s,d.work); pn(s); },
  table(d){ const s=mk(); tag(s,d.tag); ttl(s,d.title);
    table(s,d.rows,{x:0.6,y:1.6,w:12.1,colW:d.colW});
    if(d.footnote) txt(s,d.footnote,{x:0.6,y:6.1,w:12.1,h:0.6,fontSize:12,italic:true,color:d.footnoteColor==="berry"?BERRY:DUSTY}); pn(s); },
  list(d){ const s=mk(); tag(s,d.tag); ttl(s,d.title);
    if(d.style==="check"){ card(s,0.6,1.5,12.1,4.5,null);
      d.items.forEach((t,i)=>txt(s,t,{x:0.9,y:1.75+i*0.62,w:11.5,h:0.5,fontSize:15,valign:"middle"})); }
    else d.items.forEach((q,i)=>{ card(s,0.6,1.5+i*0.92,12.1,0.8,null); txt(s,q,{x:0.85,y:1.5+i*0.92,w:11.6,h:0.8,fontSize:14,valign:"middle"}); });
    pn(s); },
  summary(d){ const s=mk(BERRY);
    s.addShape(pres.shapes.OVAL,{x:-1.5,y:-1.5,w:5,h:5,fill:{color:DUSTY,transparency:55},line:{type:"none"}});
    txt(s,"まとめ",{x:0.9,y:0.9,w:8,h:0.6,fontFace:TF,fontSize:20,color:GOLD});
    txt(s,d.title,{x:0.9,y:1.6,w:11,h:1.8,fontFace:TF,fontSize:32,bold:true,color:WHITE,lineSpacing:42});
    d.lines.forEach((t,i)=>txt(s,"・"+t,{x:0.9,y:3.9+i*0.6,w:11,h:0.5,fontSize:17,color:BLUSH}));
    txt(s,BRAND,{x:0.9,y:6.9,w:6,h:0.4,fontSize:12,color:GOLD}); }
};
spec.slides.forEach(d=>{ if(!T[d.type]) throw new Error("unknown slide type: "+d.type); T[d.type](d); });
pres.writeFile({fileName:spec.outFile}).then(()=>console.log("done", N, "slides ->", spec.outFile));
